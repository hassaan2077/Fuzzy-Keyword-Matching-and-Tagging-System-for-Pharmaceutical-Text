import pandas as pd
import re
from rapidfuzz import fuzz
from typing import List, Tuple
from collections import defaultdict

class SimpleFuzzyMatcher:
    
    def __init__(self):
        self.fuzzy_threshold = 90
        self.reference_data = []
        self.indication_data = []
    
    def load_reference_data(self, reference_file_path: str):
        """Load reference data with Sentiment Topic, Product Name, and Synonyms"""
        print("Loading reference data...")
        
        if reference_file_path.endswith('.xlsx'):
            df = pd.read_excel(reference_file_path)
        else:
            df = pd.read_csv(reference_file_path)
        
        for _, row in df.iterrows():
            sentiment_topic = row.get('Sentiment Topic', '')
            product_name = row.get('Product Mentioned name to be displayed', '')
            synonyms = row.get('Synonyms', '')
            
            if pd.notna(sentiment_topic) and pd.notna(synonyms):
                keywords, logic_type = self._parse_synonyms(str(synonyms))
                
                if keywords:
                    self.reference_data.append({
                        'sentiment_topic': str(sentiment_topic),
                        'product_name': str(product_name) if pd.notna(product_name) else '',
                        'keywords': keywords,
                        'logic': logic_type
                    })
        
        print(f"Loaded {len(self.reference_data)} reference entries")
        
        self.load_indication_data(reference_file_path)
    
    def load_indication_data(self, reference_file_path: str):
        """Load indication data from Indication sheet"""
        print("Loading indication data...")
        
        try:
            if reference_file_path.endswith('.xlsx'):
                indication_df = pd.read_excel(reference_file_path, sheet_name='Indications')
            else:
                print("CSV files don't support multiple sheets. Skipping indication data.")
                return
            
            for _, row in indication_df.iterrows():
                indication = row.get('Indication', '')
                
                if pd.notna(indication) and str(indication).strip():
                    self.indication_data.append(str(indication).strip())
            
            print(f"Loaded {len(self.indication_data)} indications")
            
        except Exception as e:
            print(f"Could not load indication data: {e}")
            print("Continuing without indication matching...")
    
    def _parse_synonyms(self, synonyms: str) -> Tuple[List[str], str]:
        """Parse synonyms string to extract keywords and determine AND/OR logic"""
        if not synonyms or synonyms.strip() == '':
            return [], 'OR'
        
        keywords = []
        
        
        quoted_terms = re.findall(r'"([^"]+)"', synonyms)
        keywords.extend([term.strip() for term in quoted_terms if term.strip()])
        
        synonyms_clean = re.sub(r'"[^"]+"', '', synonyms)
        
        paren_terms = re.findall(r'\(([^)]+)\)', synonyms_clean)
        for term in paren_terms:
            parts = re.split(r'\s+OR\s+', term, flags=re.IGNORECASE)
            keywords.extend([part.strip().strip('"\'') for part in parts if part.strip()])
        
        synonyms_clean = re.sub(r'\([^)]*\)', '', synonyms_clean)
        
        
        if not keywords:
            parts = re.split(r'\s+(AND|OR)\s+', synonyms_clean, flags=re.IGNORECASE)
            for part in parts:
                if part.upper() not in ['AND', 'OR']:
                    clean_part = part.strip().strip('"\'').strip()
                    if clean_part and len(clean_part) > 2:
                        keywords.append(clean_part)
        
        
        logic_type = 'AND' if re.search(r'\bAND\b', synonyms, re.IGNORECASE) else 'OR'
        
        
        unique_keywords = []
        seen = set()
        for kw in keywords:
            kw_lower = kw.lower()
            if kw_lower not in seen and len(kw) > 2:
                seen.add(kw_lower)
                unique_keywords.append(kw)
        
        return unique_keywords, logic_type
    
    def process_test_file(self, test_file_path: str) -> pd.DataFrame:
        """Process test file and add Fuzzy Match column"""
        print("Loading test file...")
        
        if test_file_path.endswith('.xlsx'):
            df = pd.read_excel(test_file_path)
        else:
            df = pd.read_csv(test_file_path)
        
        print(f"Loaded {len(df)} rows from test file")
        
       
        df['Fuzzy Match'] = ''
        df['Indications with Fuzzy Match'] = ''
        
        row_matches = defaultdict(list)
        indication_matches = defaultdict(list)
        
        print("Processing fuzzy matching...")
        
        for ref_entry in self.reference_data:
            sentiment_topic = ref_entry['sentiment_topic']
            product_name = ref_entry['product_name']
            keywords = ref_entry['keywords']
            logic_type = ref_entry['logic']
            
            print(f"Checking: {sentiment_topic} with {len(keywords)} keywords ({logic_type} logic)")
            
            for idx, row in df.iterrows():
                text = str(row.get('Text', '')) if pd.notna(row.get('Text', '')) else ''
                
                if len(text.strip()) < 10:
                    continue
                
                if self._check_keywords_match(text, keywords, logic_type):
                    topic_part = sentiment_topic if sentiment_topic else "Unknown Topic"
                    product_part = product_name if product_name else "Unknown Product"
                    
                    match_string = f"{topic_part} - {product_part}"
                    
                    if match_string not in row_matches[idx]:
                        row_matches[idx].append(match_string)
        
        if self.indication_data:
            print("Processing indication matching...")
            for indication in self.indication_data:
                print(f"Checking indication: {indication}")
                
                for idx, row in df.iterrows():
                    text = str(row.get('Text', '')) if pd.notna(row.get('Text', '')) else ''
                    
                    if len(text.strip()) < 10:
                        continue
                    
                    if self._check_indication_match(text, indication):
                        if indication not in indication_matches[idx]:
                            indication_matches[idx].append(indication)
        
        for idx in range(len(df)):
            if idx in row_matches and row_matches[idx]:
                df.at[idx, 'Fuzzy Match'] = "; ".join(row_matches[idx])
            elif len(str(df.iloc[idx].get('Text', '')).strip()) < 10:
                df.at[idx, 'Fuzzy Match'] = 'Insufficient text content'
            else:
                df.at[idx, 'Fuzzy Match'] = 'No match found'
        
        for idx in range(len(df)):
            if idx in indication_matches and indication_matches[idx]:
                df.at[idx, 'Indications with Fuzzy Match'] = "; ".join(indication_matches[idx])
            elif len(str(df.iloc[idx].get('Text', '')).strip()) < 10:
                df.at[idx, 'Indications with Fuzzy Match'] = 'Insufficient text content'
            else:
                df.at[idx, 'Indications with Fuzzy Match'] = 'No Indication Matched'
        
        return df
    
    def _check_keywords_match(self, text: str, keywords: List[str], logic_type: str) -> bool:
        """Check if keywords match in text using fuzzy matching with AND/OR logic"""
        text_lower = text.lower()
        text_clean = re.sub(r'[^\w\s]', ' ', text_lower)
        text_words = set(text_clean.split())
        
        keyword_matches = []
        
        for keyword in keywords:
            keyword_lower = keyword.lower()
            keyword_clean = re.sub(r'[^\w\s]', ' ', keyword_lower)
            
            if keyword_lower in text_words:
                keyword_matches.append(True)
                continue
            
            if len(keyword) <= 3:
                pattern = r'\b' + re.escape(keyword_lower) + r'\b'
                keyword_matches.append(bool(re.search(pattern, text_lower)))
                continue
            
            partial_score = fuzz.partial_ratio(keyword_lower, text_lower)
            token_score = fuzz.token_sort_ratio(keyword_clean, text_clean)
            wratio_score = fuzz.WRatio(keyword_clean, text_clean)
            
            max_score = max(partial_score, token_score, wratio_score)
            keyword_matches.append(max_score >= self.fuzzy_threshold)
        
        if logic_type == 'AND':
            return all(keyword_matches) if keyword_matches else False
        else:  
            return any(keyword_matches) if keyword_matches else False
    
    def _check_indication_match(self, text: str, indication: str) -> bool:
        """Check if indication matches in text using fuzzy matching"""
        text_lower = text.lower()
        text_clean = re.sub(r'[^\w\s]', ' ', text_lower)
        text_words = set(text_clean.split())
        
        indication_lower = indication.lower()
        indication_clean = re.sub(r'[^\w\s]', ' ', indication_lower)
        
        if indication_lower in text_words:
            return True
        
        if len(indication) <= 3:
            pattern = r'\b' + re.escape(indication_lower) + r'\b'
            return bool(re.search(pattern, text_lower))
        
        partial_score = fuzz.partial_ratio(indication_lower, text_lower)
        token_score = fuzz.token_sort_ratio(indication_clean, text_clean)
        wratio_score = fuzz.WRatio(indication_clean, text_clean)
        
        max_score = max(partial_score, token_score, wratio_score)
        return max_score >= self.fuzzy_threshold
    
    def save_results(self, df: pd.DataFrame, output_path: str):
        """Save results to file"""
        if output_path.endswith('.xlsx'):
            df.to_excel(output_path, index=False)
        else:
            df.to_csv(output_path, index=False, encoding='utf-8')
        print(f"Results saved to: {output_path}")
    
    def generate_report(self, df: pd.DataFrame):
        """Generate simple report"""
        total_rows = len(df)
        matched_rows = len(df[(df['Fuzzy Match'] != 'Insufficient text content') & 
                             (df['Fuzzy Match'] != 'No match found') & 
                             (df['Fuzzy Match'] != '')])
        insufficient_text = len(df[df['Fuzzy Match'] == 'Insufficient text content'])
        no_match = len(df[df['Fuzzy Match'] == 'No match found'])
        
        indication_matched_rows = len(df[(df['Indications with Fuzzy Match'] != 'Insufficient text content') & 
                                        (df['Indications with Fuzzy Match'] != 'No Indication Matched') & 
                                        (df['Indications with Fuzzy Match'] != '')])
        no_indication_match = len(df[df['Indications with Fuzzy Match'] == 'No Indication Matched'])
        
        print("\n" + "="*60)
        print("FUZZY MATCHING REPORT")
        print("="*60)
        print(f"Total rows: {total_rows}")
        print(f"\nSENTIMENT TOPIC & PRODUCT MATCHING:")
        print(f"   Matched rows: {matched_rows} ({matched_rows/total_rows*100:.1f}%)")
        print(f"   No match: {no_match} ({no_match/total_rows*100:.1f}%)")
        print(f"   Insufficient text: {insufficient_text} ({insufficient_text/total_rows*100:.1f}%)")
        print(f"\nINDICATION MATCHING:")
        print(f"   Matched rows: {indication_matched_rows} ({indication_matched_rows/total_rows*100:.1f}%)")
        print(f"   No indication match: {no_indication_match} ({no_indication_match/total_rows*100:.1f}%)")
        print(f"\nFuzzy threshold: {self.fuzzy_threshold}%")

def main():
    reference_file = "QPharma - LEO Pharma_Products Mentioned and Indication_CHE  AD_March 2025 .xlsx"
    test_file = "LEO_CHE_AD_June_Month_Sentiment_07112025_Final_For_Upload.xlsx"
    output_file = "fuzzy_matched_results.xlsx"
    
    matcher = SimpleFuzzyMatcher()
    
    try:
        matcher.load_reference_data(reference_file)
        
        results_df = matcher.process_test_file(test_file)
        
        matcher.generate_report(results_df)
        
        matcher.save_results(results_df, output_file)
        
        print("\nProcessing complete!")
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()